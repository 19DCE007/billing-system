import java.io.*;
import java.util.*;
public class Exp
{
    public static void main(String aregs[])
    {
        Scanner kb = new Scanner(System.in);
        String[] arr = new String[10];
        arr[0] = kb.next;
        System.out.println(arr[0]);
    }
}